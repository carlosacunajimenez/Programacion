package EjercicioCasa;

import java.util.ArrayList;

public class AlumnoRegular extends Alumno{
	public AlumnoRegular() {
		
	}
	
	public boolean pagarInscripcion() {
		boolean pagado = true;
		return pagado;
	}
	public void matricularse(ArrayList<String> matriculas) {
		matriculas.add(nombre);
	}

}
