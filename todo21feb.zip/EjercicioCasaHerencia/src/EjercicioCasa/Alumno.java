package EjercicioCasa;

public class Alumno {
	String nombre;
	String clase;
	int grado;
	int grupo;
	
	public void ir_a_clase() {
		System.out.println("De camino a clase");
	}
	public void estudiar() {
		System.out.println("Estudiando");
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre1) {
		this.nombre = nombre1;
	}
	public String getClase() {
		return clase;
	}
	public void setClase(String clase1) {
		this.clase = clase1;
	}
	public int getGrado() {
		return grado;
	}
	public void setGrado(int grado1) {
		this.grado = grado1;
	}
	public int getGrupo() {
		return grupo;
	}
	public void setGrupo(int grupo1) {
		this.grupo = grupo1;
	}

}
