package EjercicioCasa;

import java.util.ArrayList;

public class AlumnoMain {
	public static void main(String[] args) {
	AlumnoRegular pepe = new AlumnoRegular();
	ArrayList<String> m1 = new ArrayList<String>();

	pepe.setNombre("Pepe");

	pepe.setClase("Biologia,matematicas");

	pepe.setGrado(2);

	pepe.setGrupo(4);

	pepe.ir_a_clase();

	AlumnoIntercambio luis = new AlumnoIntercambio("Luis","Fisica,Ecologia",1,2);

	luis.ir_a_clase();

	luis.estudiar();

	luis.matricularse(m1);
	
	System.out.println(m1.toString());

}
}