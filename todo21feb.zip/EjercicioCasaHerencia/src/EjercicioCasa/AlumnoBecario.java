package EjercicioCasa;

import java.util.ArrayList;

public class AlumnoBecario extends Alumno{
	public AlumnoBecario() {
		
	}
	
	public void pagarInscripcion(ArrayList<String> alumnosPagados) {
		alumnosPagados.add(nombre);
	}

}
