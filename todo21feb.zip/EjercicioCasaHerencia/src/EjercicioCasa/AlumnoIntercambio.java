package EjercicioCasa;

import java.util.ArrayList;

public class AlumnoIntercambio extends Alumno{
	
	public AlumnoIntercambio(String nombre1, String clase1, int grado1, int grupo1) {
		this.nombre = nombre1;
		this.clase = clase1;
		this.grado = grado1;
		this.grupo = grupo1;
		
	}
	public void matricularse(ArrayList<String> matriculas) {
		matriculas.add(nombre);
	}
	public void setNombre(String nombre1) {
		this.nombre=nombre1;
	}

	public void setClase(String clase1) {
		this.clase = clase1;
	}
	public void setGrado(int grado1) {
		this.grado = grado1;
	}
	
	public void setGrupo(int grupo1) {
		this.grupo = grupo1;
	}

}
