package frametest2;
 
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.*;
import java.applet.Applet;
 
public class jframe extends JFrame implements ActionListener {
	
	
	
	
	public static JLabel label = new JLabel("N�mero de clicks: 0");
	public static int count = 0;
	 static JButton button1 = new JButton("S�");
     static JButton button2 = new JButton("No");
 
    
 
    public jframe() {
 
        // set flow layout for the frame
        this.getContentPane().setLayout(new FlowLayout());
        
        
 
        //set action listeners for buttons
        button1.addActionListener(this);
        button2.addActionListener(this);
 
        //add buttons to the frame
        add(button1);
        add(button2);
        
 
    }
 
    @Override
    public void actionPerformed(ActionEvent ae) {
    	 count++;
     	  label.setText("N�mero de clicks: " + count);
        String action = ae.getActionCommand();
        if (action.equals("S�")) {
            System.out.println("Bot�n de s� pulsado!");
        }
        else if (action.equals("No")) {
            System.out.println("Bot�n de no pulsado!");
        }
    }
 
    private static void createAndShowGUI() {
 
  //Create and set up the window.
    	
 
  
 
  JFrame frame = new jframe();
 
  //Display the window.
  
  JPanel panel = new JPanel();
  panel.setBorder(BorderFactory.createEmptyBorder(30, 15, 30, 0));
 
  
 
  
  panel.add(label);

  frame.add(panel, BorderLayout.CENTER);
  
  frame.pack();
 
  frame.setVisible(true);
 
  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  
 
 
 
    }
    public void init() {
    	
    }
   
 
    public static void main(String[] args) {
 
  //Schedule a job for the event-dispatching thread:
 
  //creating and showing this application's GUI.
 
  javax.swing.SwingUtilities.invokeLater(new Runnable() {
 
public void run() {
 
    createAndShowGUI(); 
 
}
 
  });
  
    }
    
 
}