package frametest2;

import java.util.Scanner;

public class ahorcadotest {
	public static String palabra;
	public static int longitud;

	public static void main(String args[]) {
		Scanner a = new Scanner(System.in);
		System.out.println("Introduzca una palabra:");
		palabra = a.next();
		String palabraResolver = "";
		String palabraResolver2 = "";
		int b = 1;
		String letra = "";
		String tempString = "";
		int cont = 0;
		String palabraSolucion;

		System.out.println("Comienza el juego");
		longitud = palabra.length();
		int i = 0;
		for (i = 0; i <= longitud - 1; i++) {
			palabraResolver = palabraResolver + "_";

		}
		char[] palabraResolverChar = palabraResolver.toCharArray();
		System.out.println("Su palabra tiene: " + longitud + " caracteres");
		System.out.println("");
		System.out.println(palabraResolver);

		do {
			boolean flag = false;
			Scanner c = new Scanner(System.in);
			System.out.println("");
			System.out.println("Introduzca una letra");
			letra = c.next().toLowerCase();
			if (letra.length() > 1) {
				System.out.println("No puede poner mas de una letra");
			}
			for (i = 0; i <= longitud - 1; i++) {
				if (letra.charAt(0) == palabra.charAt(i)) {
					palabraResolverChar[i] = letra.charAt(0);
					flag = true;
					continue;
				}
			}

			if (!flag) {
				cont++;
			}

			palabraSolucion = String.valueOf(palabraResolverChar);
			System.out.println("Su palabra ahora mismo es: " + palabraSolucion);
			dibujo(cont - 1);
		} while (!palabra.equals(palabraSolucion) && cont < 6);

		if (palabra.equals(palabraSolucion)) {
			System.out.println("�GANASTE!");
		} else {
			System.out.println("" + "�MORISTE!");
		}

		/*
		 * System.out.println(" ___ "); System.out.println("/   \\");
		 * System.out.println("\\___/"); System.out.println("  | ");
		 * System.out.println("\\ |  "); System.out.println(" \\|  ");
		 */

	}

	public static void dibujo(int cont1) {
		switch (cont1) {
		case 0:
			System.out.println(" ___ ");
			System.out.println("/   \\");
			System.out.println("\\___/");
			break;
		case 1:
			System.out.println(" ___ ");
			System.out.println("/   \\");
			System.out.println("\\___/");
			System.out.println("  | ");
			break;
		case 2:
			System.out.println(" ___ ");
			System.out.println("/   \\");
			System.out.println("\\___/");
			System.out.println("  | ");
			System.out.println("\\ |");
			System.out.print(" \\| \n");
			break;
		case 3:
			System.out.println(" ___ ");
			System.out.println("/   \\");
			System.out.println("\\___/");
			System.out.println("  | ");
			System.out.println("\\ | /");
			System.out.println(" \\|/");
			break;
		case 4:
			System.out.println(" ___ ");
			System.out.println("/   \\");
			System.out.println("\\___/");
			System.out.println("  | ");
			System.out.println("\\ | /");
			System.out.println(" \\|/");
			System.out.println("  |");
			System.out.println("  |");
			System.out.println(" /");
			System.out.println("/   ");
			break;
		case 5:
			System.out.println(" ___ ");
			System.out.println("/   \\");
			System.out.println("\\___/");
			System.out.println("  | ");
			System.out.println("\\ | /");
			System.out.println(" \\|/");
			System.out.println("  |");
			System.out.println("  |");
			System.out.println(" / \\");
			System.out.println("/   \\");
		default:

		}

	}
}
