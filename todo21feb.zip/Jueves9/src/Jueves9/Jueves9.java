package Jueves9;

public class Jueves9 {
	String nombre;
	int edad;
	double altura;
	public Jueves9() {
		nombre = "Carlos";
		edad = 12;
		altura = 6.54;
	}
	public String getNombre() {
		return nombre;
	}
	public String setNombre(String nombre1) {
		nombre = nombre1;
		return nombre;
	}
	public int getEdad() {
		return edad;
	}
	public void setEdad(int edad1) {
		edad = edad1;
		
	}
	public Double getAltura() {
		return altura;
	}
	public void setAltura(double altura1) {
		altura = altura1;
	}

}
