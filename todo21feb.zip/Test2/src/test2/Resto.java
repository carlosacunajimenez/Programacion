package test2;

public class Resto {
	public static void main(String[] args) {
		int a = 0;
		
		System.out.println(a%2);
	
	
	
	

}

}