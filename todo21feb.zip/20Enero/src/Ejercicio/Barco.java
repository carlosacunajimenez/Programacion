package Ejercicio;

public class Barco extends Acuatico{

	public Barco(String nombreVehiculo) {
		super(nombreVehiculo);
		
	}
	public static void prenderMotor() {
		System.out.println("Prendiendo motor");
	}

}
