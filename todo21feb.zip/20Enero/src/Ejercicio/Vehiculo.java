package Ejercicio;

public class Vehiculo {
	public String nombreVehiculo = "Random";
	public Vehiculo (String nombreVehiculo) {
		this.nombreVehiculo = nombreVehiculo;
		
	}
	public static void Transportar() {
		System.out.println("Transportando");
	}

}
