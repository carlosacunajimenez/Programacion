package entornozzz;

public class circulo {
	protected double x,y;
	protected double r;
	public circulo(double x, double y, double r) {
		this.x = x;
		this.y = y;
		this.r = r;
	}
	public double area() {
		return Math.PI*r*r;
		
	}
	/*
	 * @param px componente x del punto
	 * @param py componente y del punto
	 * @return true si el puto esta dentro del circulo o false en otro caso
	 */
	public boolean contiene(double px, double py) {
		double d = Math.sqrt((px-x)*(px-x)+(py-y)*(py-y));
		return d <=r;
	}

}
