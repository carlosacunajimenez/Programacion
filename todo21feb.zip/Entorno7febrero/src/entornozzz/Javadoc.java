package entornozzz;

/*
 * Javadoc comenta la estructura de una aplicacion
 * Es muy similar a los comentarios multilineas
 * salvo que posee palabras claves
 * 
 * @author Carlos
 * @version 1.0
 * @see <a href="https://www.youtube.com/watch?v=qf5z2yoLZQU"> Javadoc </a>
 * @see <a href="https://www.youtube.com/watch?v=qf5z2yoLZQU"> JDK </a>
 */

public class Javadoc {
	/**
	 * m�todo que imprime un mensajes
	 * @param args argumentos del programa
	 */

	public static void main(String[] args) {
		System.out.println("Hola mundo");
	}
}
