package entornozzz;

/*
 * por favor consulte {@link com.web.javadocperson} class
 * for true identity
 * @author carlos
 */
public class Superhero extends Javadoc{
         //fields and methods
	/**
	 * the public name of a hero that is common knowledge
	 */
	private String heroName;
	/*
	 * <p> Esta es una descripci�n b�sica </p>
	 * <a href="www.google.es"> Ver datos </a>
	 * 
	 * @param incomingDamage, level of damage
	 * @return valor de salud despues del ataque
	 * @see <a href="www.google.es"Q> link </a>
	 * @since 1.0
	 */
	public int successfullyAttacked(int incomingDamage) {
		return 0;
	}
	/*
	 * @param text the string to display. if the text is null, the tool
	 * tip is turned off for this component
	 */
}
