package entornozzz;
/**
* @author carlos
* @version 1.0
* @see Persona
*/
public class Empleado{
   /**
    * Declaramos variables que entran en la clase
    * @param numeroEmpleado guardando un valor numerico
    * @param Departamento guardando un String del departamento
    * @param puesto guardando un String del puesto
    */
   private int numeroEmpleado;
   private String departamento;
   private String puesto;

public Empleado() {
}
/**
 * Parametros que entran en el constructor
* @param nombre
* @param edad
* @param numeroEmpleado
* @param departamento
* @param puesto
*/
public Empleado(String nombre, 
       int edad,
       char sexo,
       int numeroEmpleado,
       String departamento,
       String puesto) {
   /**
    * 
    * @param nombre
    * @param edad
    * @param sexo
    * @param numeroEmpleado
    * @param departamento
    * @param puesto
    */
       //super(nombre, edad, sexo);
       this.numeroEmpleado = numeroEmpleado;
       this.departamento = departamento;
       this.puesto = puesto;
}
/**
 * Getter que devuelve el numero de empleado
* @retun NumeroEmpleado
*/
public int getNumeroEmpleado() {
   return numeroEmpleado;
}
/**
 * Setter que cambia el numero de empleado
* @param numeroEmpleado
*/
public void setNumeroEmpleado(int numeroEmpleado) {
   this.numeroEmpleado = numeroEmpleado;
}
/**
 * Getter que devuelve un departamento
* @return departamento
*/
public String getDepartamento() {
   return departamento;
}
/**
 * Setter que cambia el departamento
* @param departamento
*/
public void setDepartamento(String departamento) {
   this.departamento = departamento;
}
/**
 *Getter que devuelve un puesto
* @return puesto
*/
public String getPuesto() {
   return puesto;
}
/**
 * Setter que cambia un puesto
* @param puesto
*/
public void setPuesto(String puesto) {
   this.puesto = puesto;
}
}