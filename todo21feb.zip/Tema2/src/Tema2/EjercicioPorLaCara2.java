package Tema2;

public class EjercicioPorLaCara2 {
	public static void main(String[] args) {
		int precio = 50;
		
		if(precio>100) {
			System.out.println("El precio es mayor que 100");
		} else {
			System.out.println("El precio es menor que 100");
		}
	}

}
