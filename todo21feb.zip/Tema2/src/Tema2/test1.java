package Tema2;

public class test1 {
	public static void main(String[] args) {
		int time = 22;
		 
		 if (time < 10) {
			 System.out.println("Good morning.");
			 } else if (time < 20) {
				 System.out.println("Good Day.");
			 } else {
				 System.out.println("Good evening.");
			 }
		}
	}


