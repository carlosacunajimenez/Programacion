package Tema2;

public class Tema2 {
	  public static void main(String [] args) {

	        String cabecera = "\n\tPRONOSTICO DE CLIMA:\n";
	        cabecera += "\n\tDia\t\tMa�ana\tNoche\tCondiciones\n";

	        System.out.print(cabecera);

	        String pronostico = "\tDomingo\t\t25C\t23C\tSoleado\n";

	        pronostico += "\tMartes\t\t26C\t15C\tNublado\n";

	        System.out.print(cabecera + pronostico);
	        
	        /* tabulador => \n
	         * retorno de carro => \r
	         * retroceso => \b
	         * nueva linea => \n
	         * nueva pagina => \f
	         * comillas simples = \'
	         * comillas dobles => \"
	         */
	       
	        }

	    }

	


