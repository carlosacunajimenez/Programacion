package Tema2;

public class masBucles {
	public static void main(String args[]) {
		
		int x = 0;
		while (x <= 10) {
			System.out.println("El valor de x es: " + x);
			x ++;
		}
	
	int x2 = 0;
	boolean cond = true;
	while(cond) {
		System.out.println("valor: " + x2);
		x2++;
		
		if (x2>8) {
	cond = false;
		
		
	}
	}

	int tabla = 5;
	System.out.println("Bienvenidos DAM");
	
	int j = 0;
	while (j<=10) {
		System.out.println("xd");
		System.out.println(tabla + " x " + j + " = " + (tabla*j));
		j++;
	}
}
}
