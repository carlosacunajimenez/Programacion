package Martes16;

public class jueves18v2 {
	public static void main (String[] args) throws java.lang.Exception
	{
		Integer i = null;
		Integer j = 10;
		
		System.out.println(j instanceof Integer);
		System.out.println(i instanceof Integer); //instancia es una copia de una objeto
		//Object obj = NULL; //peta
		Object obj1 = null; //ok
		
		String str = null;
		Double dbl = null;
		
		String myStr = (String) null;
		Integer myItr = (Integer) null;
		Double myDbl = (Double) null;
		
	}

}
