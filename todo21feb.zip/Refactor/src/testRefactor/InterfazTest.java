package testRefactor;

public interface InterfazTest {

}