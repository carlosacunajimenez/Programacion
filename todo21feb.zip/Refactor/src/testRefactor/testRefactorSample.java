package testRefactor;

public class testRefactorSample implements InterfazTest {
	String nameProgram = "Test Refactors";
	private int versionProgram = 1;
	public static void main(String[] args) {
		System.out.println("Hello World");
		
		//boolean valueFinal = max(5,7);
		boolean valueFinal = calculeBoolValues();
		
		
		System.out.println("Value max: " + valueFinal);
		
	}
	private static boolean calculeBoolValues() {
		boolean valueFinal = max(5,7);
		return valueFinal;
	}
	public static boolean max(int a, int b) {
		if(a > b) {
			return true;
		} else if (a == b){
			return false;
		} else {
			return false;
		}
	}
	int getVersionProgram() {
		return versionProgram;
	}
	void setVersionProgram(int versionProgram) {
		this.versionProgram = versionProgram;
	}

}
