package testRefactor;

public class ClasePrincipal {
	public static void main(String[] args) {
		String nombre;
	}

}
