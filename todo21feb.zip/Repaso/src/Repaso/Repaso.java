package Repaso;
/**
 * 
 * @author Carlos
 * Ejercicio: repaso antes del examen
 *
 */
public class Repaso {
	public static void main(String[] args) {
		int x = 5;
		float y = 5.4f;
		boolean casado = true;
		double z = 22.55;
		String name = "xd";
		char sexo = 'M';
		short notaAlumno = 7;
		long dniAlumno = 2343249283L;
		byte valueBytes = 1;
		final int constante = 47;
		
		System.out.println("variable1:" + x);
		System.out.println("variables1: + x");
		System.out.print("\n");
		System.out.format("valor variable: %s \n", x);
		System.out.printf("valor: %.2f", z);
		System.out.print("\n");
		
		int yy = (int)z;
		
		String st1 = "7";
		int b = 0;
		b = Integer.parseInt(st1);
		
		int notaA = 5;
		int notaB = 7;
		if (notaA > notaB) {
			System.out.println("Mejora nota A");
		} else {
			System.out.println("Mejor nota B");
		}
	
	for(int i=0; i<=4; i++) {
		System.out.println("Carlos");
		
		
	}

	}
}
