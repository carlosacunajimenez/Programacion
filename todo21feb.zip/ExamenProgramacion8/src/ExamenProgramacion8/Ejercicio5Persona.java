package ExamenProgramacion8;

public class Ejercicio5Persona implements Ejecicio5{
	String raza = "Caucasico";
	int altura = 180;
	String color = "Blanco";
	String nombre = "Jose";
	int edad = 30;
	
	public Ejercicio5Persona() {
		
	}
	
	
	
	public String cambiarColor(String color1) {
		color = color1;
		return color;
	}
	@Override
	public int reducirEdad(int edad1) {
		edad = edad - edad1;
		return edad;
	}
	@Override
	public String cambiarNombre(String nombre1) {
		nombre = nombre1;
		return nombre;
	}

}
