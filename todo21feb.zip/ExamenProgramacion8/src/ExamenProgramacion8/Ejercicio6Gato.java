package ExamenProgramacion8;

public class Ejercicio6Gato extends Ejercicio6Animal{
	public String tipoU�as = "Largas";
	public String color = "Romano";
	public String Alimentacion= "Carn�voro";
	
	public Ejercicio6Gato() {
		
	}
	public boolean esCojo(int patas) {
		boolean cojera = true;
		if(patas>=4) {
			System.out.println("Su gato no es cojo");
			return !cojera;
		} else {
			System.out.println("Su gato es cojo");
			return cojera;
		}
	}
	public  void estaCastrado() {
		System.out.println("Sentimos comentarle que su gato se encuentra castrado");
	}
	public void cambiarAlimentacion(String tipoAlimentacion) {
		Alimentacion = tipoAlimentacion;
	}

}
