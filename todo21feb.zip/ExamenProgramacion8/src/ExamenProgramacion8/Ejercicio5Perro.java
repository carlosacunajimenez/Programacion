package ExamenProgramacion8;

public class Ejercicio5Perro extends Ejercicio5Persona{
    String alimentacion = "Carnivoro";
    int velocidadCarrera = 100;
    String color = "negro";
    int edad = 50;
    String nombre = "PerroTest";
    
	public Ejercicio5Perro() {
		
	}
	public Ejercicio5Perro(String raza1) {
		this.nombre=super.nombre;
	}
	public String cambiarColor(String color1) {
		color = color1;
		return null;
	}

	
	public int reducirEdad(int edad1) {
		edad = edad1;
		return edad;
	}

	
	public String cambiarNombre(String nombre1) {
		nombre = nombre1;
		return nombre;
	}
	

}
