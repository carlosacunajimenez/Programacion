package ExamenProgramacion8;

public interface Ejecicio5 {
	String nombre = "";
	int edad = 0;
	String color = "";
	
	public String cambiarColor(String color);
	
	public int reducirEdad(int edad);
	
	public String cambiarNombre(String nombre); 

}
