package ExamenProgramacion8;

public interface Interfaz71 {
	String nombre="";
	int edad = 0;
	int altura = 0;
	int numeroHermanos = 0;
	
	public void cambiarEdad(int edad1);
	public void cambiarAltura(int altura1);

}
