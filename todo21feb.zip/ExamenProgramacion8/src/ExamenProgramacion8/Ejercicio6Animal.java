package ExamenProgramacion8;

public class Ejercicio6Animal {
	public String nombre = "";
	public int edad = 0;
	public int tama�o = 0;
	
	public String cambiarNombre(String nombre1) {
		nombre = nombre1;
		return nombre;
	}
	public int cambiarEdad(int edad1) {
		edad = edad1;
		return edad;
	}
	public int cambiarTama�o(int tama�o1) {
		tama�o = tama�o1;
				return tama�o;
	}

	}


