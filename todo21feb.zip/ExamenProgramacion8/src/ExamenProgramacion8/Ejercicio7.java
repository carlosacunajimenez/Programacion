package ExamenProgramacion8;

public class Ejercicio7 implements Interfaz71, Interfaz72,Interfaz73{

	String nombre = "Carlos";
	int altura = 180;
	int edad = 25;
	int numeroHermanos = 6;
	String pais = "Espa�a";
	String hobby = "Gimnasio";
	boolean huerfano = false;
	boolean miope = true;
	boolean algunaEnfermedad = true;
	String genero = "masculino";
	
	public Ejercicio7() {
		
	}
	
	public void cambiarPais(String pais1) {
		pais = pais1;
		
	}

	@Override
	public void nuevoHobby(String hobby1) {
		hobby = hobby1;
		
	}

	@Override
	public void cambiarEdad(int edad1) {
	edad = edad1;
		
	}

	@Override
	public void cambiarAltura(int altura1) {
		altura = altura1;
		
	}

	@Override
	public void consultaMiopia(int dioctrias) {
		if(dioctrias>2) {
			System.out.println("Estas ciego");
		} else {
			System.out.println("Ves perfecto");
		}
		
	}

}
