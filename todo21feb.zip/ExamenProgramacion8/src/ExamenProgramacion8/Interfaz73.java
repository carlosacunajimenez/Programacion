package ExamenProgramacion8;

public interface Interfaz73 {
	boolean miope = true;
	boolean algunaEnfermedad = true;
	String genero = "";
	
	public void consultaMiopia(int dioctrias);

}
