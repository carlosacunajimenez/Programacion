package ExamenProgramacion8;

public class Ejercicio7Main extends Ejercicio7{
	public static void main(String[] args) {
		Ejercicio7 obj1 = new Ejercicio7();
		System.out.println("Variables: " + obj1.altura + " "+ obj1.edad+ " "+ obj1.genero + " "+ obj1.hobby + " "+ obj1.nombre + " "
				+ obj1.numeroHermanos + " "+ obj1.pais + " " + obj1.algunaEnfermedad + " " + obj1.huerfano
				+ " " + obj1.miope);
		System.out.println("M�todos: ");
		obj1.cambiarAltura(150);
		obj1.cambiarEdad(30);
		obj1.cambiarPais("Francia");
		obj1.consultaMiopia(4);
		obj1.nuevoHobby("Estudiar");
		System.out.println("Cambios: "+ obj1.altura + " "+ obj1.edad + " " +obj1.pais + " " + obj1.hobby);
	}
	

}
