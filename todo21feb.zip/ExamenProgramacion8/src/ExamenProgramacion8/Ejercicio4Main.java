package ExamenProgramacion8;

public class Ejercicio4Main {
	public static void main(String[] args) {
		Ejercicio4Rectangulo r1 = new Ejercicio4Rectangulo();
		Ejercicio4Rectangulo r2 = new Ejercicio4Rectangulo(50.00, 70.00);
	    System.out.println(r1.area());
	    System.out.println(r2.area());
	    System.out.println(r1.propietario("Carlos"));
	    System.out.println(r2.propietario("Alvaro"));
	    System.out.println(r1.numeroFigura());
	    System.out.println(r2.numeroFigura());
	    r1.eliminarLado();
	    r2.eliminarLado();
	}

}
