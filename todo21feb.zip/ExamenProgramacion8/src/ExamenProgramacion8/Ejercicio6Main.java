package ExamenProgramacion8;

public class Ejercicio6Main {
	public static void main(String[] args) {
		Ejercicio6Gato gato1 = new Ejercicio6Gato();
		Ejercicio6Caballo caballo1 = new Ejercicio6Caballo();
		Ejercicio6Caballo caballo2 = new Ejercicio6Caballo("Ponyta", 10, 50, "Acero", "Competici�n", 10, 10);
		System.out.println("Variables de gato: " + gato1.Alimentacion + " " + gato1.color
				+ gato1.edad + " " + gato1.nombre + gato1.tama�o + " " + gato1.tipoU�as);
		gato1.cambiarAlimentacion("Vegetariano");
		gato1.cambiarEdad(30);
		gato1.cambiarNombre("Willy");
		gato1.cambiarTama�o(70);
		gato1.esCojo(3);
		gato1.estaCastrado();
		System.out.println("Variables cambiadas: " + gato1.edad + " "+ gato1.nombre + " "+ gato1.tama�o + " " + gato1.Alimentacion);
		System.out.println("Variables del caballo: " + caballo1.a�osCompitiendo + " "
		+ caballo1.edad + " " + caballo1.estadoHerradura + " "
		 + caballo1.herradura + " " + caballo1.nombre+ " " + caballo1.tipoCaballo + " " + caballo1.tama�o);
		System.out.println("Variables del caballo: " + caballo2.a�osCompitiendo + " "
				+ caballo2.edad + " " + caballo2.estadoHerradura + " "
				 + caballo2.herradura + " " + caballo2.nombre+ " " + caballo2.tipoCaballo + " " + caballo2.tama�o);
		caballo1.a�osRestantesCompitiendo();
		caballo1.cambiarEdad(30);
		caballo1.cambiarTama�o(40);
		caballo1.cambiarNombre("Pepe");
		caballo1.cambiarTipoCaballo("DE CAZA");
		caballo1.EstadoHerradura();
	}

}
