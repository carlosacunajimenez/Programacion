package ExamenProgramacion8;

public class Ejercicio6Caballo extends Ejercicio6Animal{
	String herradura = "Metal";
	String tipoCaballo = "Campo";
	int a�osCompitiendo = 20;
	int estadoHerradura = 5;
	public Ejercicio6Caballo() {
		
	}
	public Ejercicio6Caballo(String nombre1, int edad1, int tama�o1, String herradura1, String tipoCaballo1, int a�osCompitiendo1, int estadoHerradura1) {
		this.nombre=nombre1;
		this.edad = edad1;
		this.tama�o = tama�o1;
		this.herradura = herradura1;
		this.tipoCaballo = tipoCaballo1;
		this.a�osCompitiendo = a�osCompitiendo1;
		this.estadoHerradura = estadoHerradura1;
	}
    public int a�osRestantesCompitiendo() {
    	if(a�osCompitiendo<20) {
    		return 20;
    	} else {
    		return 10;
    	}
    }
    public void cambiarTipoCaballo(String tipoCaballo2) {
    	tipoCaballo = tipoCaballo2;
    }
    public void EstadoHerradura() {
    	if(estadoHerradura<5) {
    		System.out.println("Habr�a que reparar la herradura");
    	}
    }
    
}
