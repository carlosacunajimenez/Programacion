package ExamenProgramacion8;

public interface Interfaz72 {
String pais = "";
String hobby = "";
boolean Huerfano = false;

public void cambiarPais(String pais1);
public void nuevoHobby(String hobby1);
}
