package ExamenProgramacion8;

public class Ejercicio5MAIN extends Ejercicio5Perro{

    public static void main(String[] args) {
    	//todos las variables y m�todos testeadas adem�s de su correspondiente herencia e implementaci�n.
    	Ejercicio5Perro perroHumano = new Ejercicio5Perro();
    	Ejercicio5Perro perroHumano2 = new Ejercicio5Perro("Lobezno");
    	System.out.println(perroHumano.alimentacion);
    	System.out.println(perroHumano.altura);
    	System.out.println(perroHumano.color);
    	System.out.println(perroHumano.edad);
    	System.out.println(perroHumano.nombre);
    	System.out.println(perroHumano.raza);
    	System.out.println(perroHumano.velocidadCarrera);
    	perroHumano.cambiarColor("Negro");
    	System.out.println(perroHumano.color);
    	perroHumano.cambiarNombre("EL PERRO HUMANO");
    	System.out.println(perroHumano.nombre);
    	perroHumano.reducirEdad(5);
    	System.out.println(perroHumano.edad);
    	
    	//Aqui demuestro como controlando los constructores y la palabra super y this puedo cambiar el valor de la variable nombre:
    	System.out.println(perroHumano.nombre);
    	System.out.println(perroHumano2.nombre);
}
}