package ExamenProgramacion8;

import java.util.ArrayList;
import java.util.Scanner;

public class Ejercicio3 {
	
	public static void main(String[] args) {
		ArrayList<String> producto = new ArrayList<String>();
		ArrayList<Double> numeros = new ArrayList<Double>();
		ArrayList<Integer> unidades = new ArrayList<Integer>();
		ArrayList<Double> total = new ArrayList<Double>();
		
		for(int i=0; i<3; i++) {
			System.out.println("Introduzca el nombre de los productos");
			Scanner sc = new Scanner(System.in);
			String a = sc.next();
			producto.add(a);
		}
		for(int i=0; i<3; i++) {
			System.out.println("Introduzca el precio de los productos");
			Scanner sc = new Scanner(System.in);
			Double b = sc.nextDouble();
			numeros.add(b);
		
		
	}
		for(int i=0; i<3; i++) {
			System.out.println("Introduzca el numero de unidades de los productos");
			Scanner sc = new Scanner(System.in);
			int c = sc.nextInt();
			unidades.add(c);
		}
		for(int i=0; i<3; i++) {
			Double temp = numeros.get(i)*unidades.get(i);
			total.add(temp);
		}
		System.out.println("PRODUCTO-UNIDADES-PRECIO/UNIDAD-TOTAL");
		for(int i=0;i<3;i++) {
			System.out.println(producto.get(i) + "-"+ unidades.get(i)+ "-"+ numeros.get(i) + "-"+ total.get(i));
			
		}
		System.out.println("------------------");
		double sumatotal = total.get(0) + total.get(1) + total.get(2);
		System.out.println("Total: " + sumatotal);
}
}
