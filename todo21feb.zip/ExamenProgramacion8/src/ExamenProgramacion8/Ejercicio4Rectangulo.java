package ExamenProgramacion8;

public class Ejercicio4Rectangulo extends Ejercicio4{
   Double lado = 30.00;
   Double lado2 = 40.00;
   
  public Ejercicio4Rectangulo(){
	   
   }
   public Ejercicio4Rectangulo(Double lado, Double lado2){
	   this.lado=lado;
	   this.lado2=lado2;
   }
	
	public double area() {
	    area = lado*lado2;
		return area;
	}

	
	public String propietario(String propiedad) {
		System.out.println("El propietario de esta figura es: "+ propiedad);
		return propiedad;
	}

	
	public int numeroFigura() {
		System.out.println("Calculando numero de la figura");
		double f =  8.0*Math.random();
		return (int) f;
	}
	public void eliminarLado() {
		System.out.println("No se pueden eliminar lados de un rectangulo");
	}
	

}
