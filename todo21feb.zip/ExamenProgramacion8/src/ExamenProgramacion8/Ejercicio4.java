package ExamenProgramacion8;

public abstract class Ejercicio4 {
Double lado;
Double lado2;
Double radio;
Double area;

public abstract double area();

public abstract String propietario(String propiedad);

public abstract int numeroFigura();

public void eliminarLado() {
	
}
}
