package PreExamen;

public class Human extends LivingT{

	public Human(String nombre1) {
		super(nombre1);
		
	}

	
	public void walk() {
		System.out.println("Andando");
		
	}

}
