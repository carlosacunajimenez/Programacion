package PreExamen;

public interface LivingT2 {
	public abstract void walk();
		
	}


