package EntornoGrafico;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Login extends JFrame implements ActionListener {
	Container container = getContentPane();
	JLabel userLabel = new JLabel("USERNAME");
	JLabel passwordLabel = new JLabel("PASSWORD");
	JTextField userTextField = new JTextField();
	JPasswordField passwordField = new JPasswordField();
	JButton boton1 = new JButton("Login");
	JButton boton2 = new JButton("Reset");
	JCheckBox showPassword = new JCheckBox("Show Password");
	String loginxd;
	String pwdxd;
	
	
	Login() {
		setLayoutManager();
		setLocationSize();
		addComponentsToContainer();
		addActionEvent();
		
		
	}

	private void setLocationSize() {
		userLabel.setBounds(10, 20, 300, 30);
		
		passwordLabel.setBounds(10, 120, 300, 30);
		
		userTextField.setBounds(10,60,300,30);
		
		passwordField.setBounds(10, 160, 300,30);
		
		boton1.setBounds(200, 300, 150, 30);
		
		boton2.setBounds(0, 300, 150, 30);
		
		showPassword.setBounds(0, 400, 150, 30);
		
		
		
	}
	public void addComponentsToContainer() {
		container.add(userLabel);
		container.add(passwordLabel);
		container.add(userTextField);
		container.add(passwordField);
		container.add(boton1);
		container.add(boton2);
		container.add(showPassword);
		
	}

	private void setLayoutManager() {
		container.setLayout(null);
		
	}
	
	

	@Override
	public void actionPerformed(ActionEvent e) {
		 if (e.getSource() == boton1) {
		       loginxd = userTextField.getText();
		       pwdxd = passwordField.getText();
		       
		       if(loginxd.equalsIgnoreCase("carlos") && pwdxd.equalsIgnoreCase("1234")) {
		    	   JOptionPane.showMessageDialog(this, "Login Successful"); //aqui podemos poner null o this
		       }else {
		    	   JOptionPane.showMessageDialog(this, "Login Unsuccessful");
		       }
		    } 
		  if (e.getSource() == boton2) {
			    userTextField.setText("");
			    passwordField.setText("");
		        System.out.println("Reseateamos");
		        
		    }
		  if (e.getSource() == showPassword) {
			  if (showPassword.isSelected()) {
				  passwordField.setEchoChar((char) 0);
			  } else {
				  passwordField.setEchoChar('*');
			  }
		  }
		
	}
	public void addActionEvent() {
		boton1.addActionListener(this);
		boton2.addActionListener(this);
		showPassword.addActionListener(this);
		
	}
	public static void main(String[] a) {
		Login frame = new Login();
		frame.setTitle("Login form");
		frame.setBounds(10, 10, 370, 600);
		frame.setVisible(true);
		
		
		
	}

}
