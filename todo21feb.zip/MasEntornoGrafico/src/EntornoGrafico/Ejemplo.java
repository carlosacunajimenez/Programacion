package EntornoGrafico;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.event.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import java.awt.*;
import java.applet.Applet;

public class Ejemplo extends JFrame implements ActionListener{
	JButton boton1;
	JButton boton2;
	public static JLabel label = new JLabel("N�mero de clicks: 0");
	public static int count = 0;
	JTextField textfield1;
	
	public Ejemplo() {
		 
		 //setLayout(null);
		 
		 //setBounds(0,0,450,350);
		this.getContentPane().setLayout(new FlowLayout());
		 
		 setTitle("Ejemplo 1: Bot�n");
		 
		 boton1 = new JButton("S�");
		 boton2 = new JButton("No");
		 //boton1.setBounds(300, 250, 100, 30);
		 //boton2.setBounds(200, 150, 100, 30);
		 add(boton1);
		 add(boton2);
		    
		 setDefaultCloseOperation(EXIT_ON_CLOSE);
		 //textfield1 = new JTextField();
		 //textfield1.setBounds(0,0,0,0);
		 //add(textfield1);
		 
		 setVisible(true);
		 boton1.addActionListener(this);
	     boton2.addActionListener(this);
	     
	    
			
		}
	public static void crearYMostrar() {
	JFrame frame = new Ejemplo();
	JPanel panel = new JPanel();
	  panel.setBorder(BorderFactory.createEmptyBorder(30, 15, 30, 0));
	  JTextField textfield1 = new JTextField();
	  
	  panel.add(textfield1);
	  
	  panel.add(label);

	  frame.add(panel, BorderLayout.CENTER);
	  
	  frame.pack();
	 
	  frame.setVisible(true);
	 
	  frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	  
	 
	  
	
	}
	
	
		public static void main(String[] args) {
		    crearYMostrar();
		}
		@Override
		public void actionPerformed(ActionEvent ae) {
	    	 count++;
	     	  label.setText("N�mero de clicks: " + count);
	        String action = ae.getActionCommand();
	        if (action.equals("S�")) {
	            System.out.println("Bot�n de s� pulsado!");
	        }
	        else if (action.equals("No")) {
	            System.out.println("Bot�n de no pulsado!");
	        } 
			
		}
		/*
		 * public void actionPerformed(ActionEvent ae) {
		 * if (e.getSource() = boton1) {
		 * System.exit(0);
		 * }
		 * 
		 * if(e.getSource() = boton2) {
		 * System.out.println("HOLA");
		 * }
		 * }
		 * 
		 * 
		 */
		
	}


