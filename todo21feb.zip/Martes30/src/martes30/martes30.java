package martes30;

public class martes30 {
	String nombre;
	int edad;
	String padre;
	
	public martes30() {
		nombre = "Jose";
		edad = 2;
		padre = "carlos";
	}
	
public martes30(String text) {
	nombre=text;
}
public String getNombre() {
	return nombre;
	
}
public void setNombre(String nombre1) {
	nombre = nombre1;
	
}
public int getEdad() {
	return edad;
}
public void setEdad(int edad1) {
	edad = edad1;
}
public String getPadre() {
	return padre;
}
public void setEdad(String padre1) {
	padre = padre1;
}

	
 }
