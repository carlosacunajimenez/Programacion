package martes30;

public class martes30v2 {
	
    

public static void main(String args []) {
	String palabrarandom = "xd";
	martes30 obj1 = new martes30();
	martes30 obj2 = new martes30(palabrarandom);
	System.out.println(obj1.getNombre());
	obj1.setNombre("Miguel");
	System.out.println(obj1.getNombre());
	System.out.println(obj1.nombre);
    
	
}
}
