package testGit;

public class TestGit1 {
	public static void main(String[] args) {
		System.out.println("Hola");
	}

}
