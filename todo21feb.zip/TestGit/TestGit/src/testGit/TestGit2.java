package testGit;

public class TestGit2 {
	public static void main(String[] args) {
		System.out.println("Hola");
	}

}
