package TestHerencia;

public class DosDimensiones {
	int base = 5;
	int altura = 10;
	public DosDimensiones(){
		
	}
	public DosDimensiones(int base, int altura){
		this.base = base;
		this.altura = altura;
	}

}
