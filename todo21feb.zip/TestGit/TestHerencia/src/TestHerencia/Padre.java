package TestHerencia;

public class Padre {
	String nombre = "NombrePadre";
	int edad = 17;
	public Padre() {
	
	}
	public Padre(String nombre, int edad) {
		this.nombre = nombre;
		this.edad = edad;
	}
}
