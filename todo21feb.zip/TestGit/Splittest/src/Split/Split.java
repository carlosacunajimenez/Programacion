package Split;

public class Split {
	public static void main(String[] args) {
		String splitxd = "what-lol-kek-lul";
		String[] splitxd1 = splitxd.split("-");
		String parte1 = splitxd1[0];
		String parte2 = splitxd1[1];
		String parte3 = splitxd1[2];
		String parte4 = splitxd1[3];
		System.out.println(parte1 + " " + parte2 + " " + parte3 + " " + parte4);
		
	}

}
