package test1;

public class Divisionpor0 {
	public static void main(String[] args) {
	int a = 9;
	int b = 0;
	int suma = a/b;
	System.out.println(suma);
     
}
}
