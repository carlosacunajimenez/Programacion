package test1;

public class VarsTypes {
	

	public static void main (String[] args) {
		byte valueByte = 1;                       //8 bits
		short notaAlumno = 7;                     //16 bits
		int edadAlumno = 20;                      //32 bits
		long dniAlumno = 289999999L;              //64 bits
		                                                 //sysouts ctrl+espacio
		System.out.println("Nota del Alumno " + notaAlumno);
	}
	/*
	 *  static public byte valueByte = 1;                       //8 bits
		static public short notaAlumno = 7;                     //16 bits
		static public edadAlumno = 20;                      //32 bits
		static public dniAlumno = 289999999L;              //64 bits
		
		public static void main (String[] args) {
		System.out.println("Nota del Alumno " + notaAlumno);
		}
		}
	 */

}
