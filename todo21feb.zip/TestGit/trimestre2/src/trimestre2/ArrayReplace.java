package trimestre2;

public class ArrayReplace {
	public static void main(String[] args) {
		String URL = "http://www.medac.es";
		//String newUrl = reemplazar(URL, "Medac", "itep");
		//System.out.println(newUrl);
		
		
	}
	public static void reemplazar(String str1, String str2) {
		
	}

}
