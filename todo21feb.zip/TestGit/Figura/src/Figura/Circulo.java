package Figura;

public class Circulo implements Figura{

	@Override
	public double area() {
		// TODO Auto-generated method stub
		return 0;
	}

}
