package Figura;

public class Triangulo implements Figura{

	@Override
	public double area() {
		// TODO Auto-generated method stub
		return 0;
	}

}
