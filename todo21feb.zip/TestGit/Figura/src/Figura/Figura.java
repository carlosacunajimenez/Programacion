package Figura;

public interface Figura {
public abstract double area();
String color= "";
double lado = 0;
double radio = 0;
}
