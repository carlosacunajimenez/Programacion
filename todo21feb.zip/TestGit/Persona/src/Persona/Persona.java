package Persona;

public interface Persona {
String nombre = "";
int edad = 0;
public abstract void andar();
}
