package Persona;

public class PersonaClase implements Persona{

	String nombre = "Carlos";
	int edad = 30;
	String color = "Blanco";
	public void andar() {
		// TODO Auto-generated method stub
		
	}

}
