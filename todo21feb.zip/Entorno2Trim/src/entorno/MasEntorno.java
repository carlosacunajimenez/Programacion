package entorno;

public class MasEntorno {
	public static void main(String[] args) {
	    //Declaring a primitive type
	    int numPrimitive = 6;
	    //use type primitive
	    Integer numWrapperFormI = Integer.valueOf(numPrimitive);
	    //use valor directo
	    Integer numWrapperFormII = Integer.valueOf(55);
	    System.out.println("valor " + numWrapperFormI);
	    System.out.println(numWrapperFormII);
	}
	}


