package Tema3;

public class ClaseSecundaria {
	String saludo;
	
	public ClaseSecundaria() {
	saludo = "Buenos d�as";	
	}
	public String getSaludo() {
		return saludo;
		
	}
}
