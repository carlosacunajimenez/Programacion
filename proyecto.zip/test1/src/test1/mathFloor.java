package test1;

public class mathFloor {
	public static void main(String[] args) {
		double operador1=25.5;
		double operador2=15.21;
		
		System.out.println(Math.ceil(operador1)); //devuelve el entero mayor
		System.out.println(Math.floor(operador2));
		
		//pow/max/sqrt/ceil
}
}