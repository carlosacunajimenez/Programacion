package test1;

public class DiferentesVariables {
	String Michael;
	String Jackson;
	String Cantante;
	String Pop_Y_RYB;

}
