package test1;

public class EjercicioDecimales {
	
	//Declaraci�n de variables con static aqu� arriba

	public static void main(String[] args) {
		        float pesoAlumno = 88.77f;                                       //32 bit
				double alturaAlumno = 1.70;                                      //64 bit
			    boolean activoAlumno = true;
				char letraDniAlumno = 'K';
				System.out.println("Mensaje");
				
				String nombreAlumno = "Miguel Angel";
				String apellidosAlumno = "Yllanes lopez";
				 final String horarioAlumno = "ma�ana"; //final = constante

	}

}
