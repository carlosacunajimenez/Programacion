package test1;

public class Test2 {
	
	// crear una funci�n que auto-ejecute c�digo
	public static void main(String[] args) {
	                                    System.out.println("hola mundo");
	                                    
}

}
/* static -> ampl�a la accesibilidad, void -> no devuelve ning�n valor, al 
a�adir el static puedo llamar al m�todo en cualquier momento del codigo, si no estuviese el
static por ejemplo no podr�a llamarla en cierto momento del codigo */

//el corchete del main [] significa arrays de strings al que llamamos args