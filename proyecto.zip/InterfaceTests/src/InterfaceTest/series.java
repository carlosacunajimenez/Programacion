package InterfaceTest;

public interface series {
	int getSiguiente();
	void reiniciar();
	void setComenzar(int x);

}
