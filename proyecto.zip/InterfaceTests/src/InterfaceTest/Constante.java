package InterfaceTest;

public interface Constante {
	int MIN = 0;
	int MAX = 10;
	String MSJERROR ="LIMITE ERROR";

}
