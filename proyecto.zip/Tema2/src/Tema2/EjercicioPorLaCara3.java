package Tema2;

public class EjercicioPorLaCara3 {
	public static void main (String[] args) {
		int num = 1;
		
		while (num<=5) {
			System.out.println(num);
			num++;
		}
	}

}
