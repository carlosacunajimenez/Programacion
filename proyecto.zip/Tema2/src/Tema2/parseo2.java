package Tema2;

public class parseo2 {
	public static void main(String[] args) {
   //operadores de asignaci�n
	
	 
	 int a;           // declaraci�n
	 int b;
	 int c, d;
	 int e = 10;
	 int f = 4;      //declaraci�n y asignacion de variables
	//int g = 9;
	
	 a = 20;  //asignar valores a variables
	 b = 10;
	
	 c = b;   // Asignaci�n simple "cambiar valor"
	 
	 //operadores de asignaci�n simples
	 
	a = a + 1;
	b = b -1;
	e = e * 2;
	f = f / 2;
 
	
	System.out.println("Valor de c = " + c);
	System.out.println("a,b,e,f = " + a + ", " + b + ", " + e + ", " + f);
	
	/* operadores de asignaci�n simples
	 * a = a + 1;
	 * b = b - 1;
	 * e = e * 2;
	 * f = f / 2;
	 * System.out.println("a,b,e,f = " + a + "," + b + "," + e + "," + f);
	 * 
	 * operadores de asignaci�n compuestos/cortos
	 * a += 1;
	 * b -= 1;
	 * e *=2;
	 * f /=2;
	 * 
	 * 
	 */

}
}
