package Tema2;

public class EjercicioPorLaCara4 {
	public static void main(String[] args) {
		double operador1=25.5;
		double operador2=15.21;
		
		System.out.println(Math.ceil(operador1)); //devuelve el entero mayor
		System.out.println(Math.floor(operador2)); //devuelve el entero redondeado hacia abajo (siempre abajo)
		System.out.println(Math.pow(operador1, operador2)); //potencia operador1 base operador2 exponente
		System.out.println(Math.max(operador1, operador2)); //devuelve el mayor de los dos
		System.out.println(Math.sqrt(operador1)); //ra�z cuadrada de un numero
	}

}
