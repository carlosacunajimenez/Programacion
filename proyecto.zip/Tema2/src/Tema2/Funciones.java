package Tema2;

public class Funciones {
	public static void main(String args[]) {
	//las funciones van siempre fuera del main
		saludar();
	}
   static void saludar() {
	   System.out.println("Hola mundo");
   }
}
