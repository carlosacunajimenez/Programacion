package Tema2;

public class parseo4 {
	public static void main(String[] args) {
		int a1 = 7, b1 = 10;
		if ( a1 > b1 )
			System.out.println("a1 es mayor b1: " + a1);
		else
			System.out.println("A1 es menor b1: " + a1);
	}

}
