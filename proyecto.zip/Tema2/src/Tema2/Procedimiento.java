package Tema2;

public class Procedimiento {
	public static void main(String args[]) {
		{ //crear un procedimiento
		System.out.println("uno");
		{
			System.out.println("dos");
			{
				System.out.println("tres");
			}
		}
}
}
}