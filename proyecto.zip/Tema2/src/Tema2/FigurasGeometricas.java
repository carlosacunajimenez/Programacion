package Tema2;

public class FigurasGeometricas {
	 public static void main(String [] args) {
	        double radio = 25;
	        System.out.println("La longitud de la circunferencia es: " + (2 * Math.PI * radio));
	        //superficie del circulo
	        int a = 5;
	        System.out.println("El cuadrado de a es: " + a * a);
	        System.out.println("El cuadrado de a es: " + Math.pow(a, 2));
	    }
	}
		
		


