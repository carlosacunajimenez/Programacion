package Tema2;

import java.util.Scanner;


public class Ejercicios2 {
 public static void main(String[] args) {
	
	 Scanner s = new Scanner(System.in);
		System.out.print("ingrese un n�mero");
	    int a = s.nextInt();
	     if (a>=0) {
	    	 System.out.println("S� numero es positivo");
	     } else
	    	 System.out.println("s� n�mero es negativo");
	 
 }

 
 /* int time = 22;
 
 if (time < 10) {
	 System.out.println("Good morning.");
	 } else if (time < 20) {
		 System.out.println("Good Day.");
	 } else {
		 System.out.println("Good evening.");
	 }
}
*/
}

