package Tema2;

public class EjerciciosPorLaCara {
	public static void main(String[] args) {
		int operador1= 20;
		int operador2 = 15;
		int resultado = 0;
		
		resultado = operador1+operador2; //resultado 35
		resultado = operador1-operador2; //resultado 5
		resultado = operador2-operador1; //resultado -5
		resultado = operador1*operador2; //resultado=300
		resultado = operador1/operador2; //resultado = 1 (como es int no incluye decimales)
		resultado = operador1%operador2; //resultado = 5 (resto de la divisi�n)
	}

}
