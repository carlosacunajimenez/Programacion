package ArraysBi;

public class ObjetoTest {
	String nombre = "Carlos";

}
