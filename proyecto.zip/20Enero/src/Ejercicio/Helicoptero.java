package Ejercicio;

public class Helicoptero extends Aereo{

	public Helicoptero(String nombreVehiculo) {
		super(nombreVehiculo);
		// TODO Auto-generated constructor stub
	}
	public static void encenderHelices() {
		System.out.println("Encendiendo helices");
	}

}
