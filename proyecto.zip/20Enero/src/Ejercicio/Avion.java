package Ejercicio;

public class Avion extends Aereo{

	public Avion(String nombreVehiculo) {
		super(nombreVehiculo);
		// TODO Auto-generated constructor stub
	}
	public static void bajarTrenDeAterrizaje() {
		System.out.println("Bajando tren");
	}

}
