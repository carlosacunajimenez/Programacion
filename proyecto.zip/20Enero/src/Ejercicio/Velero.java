package Ejercicio;

public class Velero extends Acuatico{

	public Velero(String nombreVehiculo) {
		super(nombreVehiculo);
		// TODO Auto-generated constructor stub
	}
	public static void hizarVelas() {
		System.out.println("Hizando velas");
	}
	

}
