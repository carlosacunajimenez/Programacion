package Ejercicio;

public class Aereo extends Vehiculo{

	public Aereo(String nombreVehiculo) {
		super(nombreVehiculo);
		// TODO Auto-generated constructor stub
	}
	public static void volar() {
		System.out.println("Volando");
	}
	

}
