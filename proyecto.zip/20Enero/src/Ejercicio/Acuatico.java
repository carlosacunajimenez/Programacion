package Ejercicio;

public class Acuatico extends Vehiculo{
	public String nombreAcuatico;
	public Acuatico(String nombreVehiculo) {
		super(nombreVehiculo);
		
		// TODO Auto-generated constructor stub
	}
	public static void navegar() {
		System.out.println("Navegando");
	}

	
	

}
