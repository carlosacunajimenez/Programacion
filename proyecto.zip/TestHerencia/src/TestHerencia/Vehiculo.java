package TestHerencia;

public class Vehiculo {
	
	public int maxSpeed = 120;
	public String nombre = "nombre1";
	
public Vehiculo() {
	
}
}
