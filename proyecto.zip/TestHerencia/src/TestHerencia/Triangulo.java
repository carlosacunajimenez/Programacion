package TestHerencia;

public class Triangulo extends DosDimensiones{
	String estilo = "estilo predeterminado";
	public Triangulo() {
		
	}
	public Triangulo(int base, int altura, String estilo) {
		this.base = base;
		this.altura = altura;
		this.estilo = estilo;
	}
	

}
