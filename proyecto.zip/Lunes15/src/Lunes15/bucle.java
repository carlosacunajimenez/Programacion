package Lunes15;

public class bucle {
	public static void main(String[] args) {
		int contador = 0;
		for(int i=0; i<=10; i++) {
			contador += i;
		}
		System.out.print(contador);
	}

}
