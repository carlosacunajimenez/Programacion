package miercoles24;

public class miercoles24principal {
	public static void main(String[] args) {
		miercoles24 obj1 = new miercoles24();
		obj1.getYear();
		
		miercoles24 obj2 = new miercoles24("Rafael", 50);
		String temp2 = obj2.getName();
		System.out.println(temp2);
	}

}
