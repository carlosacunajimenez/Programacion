package trimestre2;

public class ifnuevo {
	public static void main(String[] args) {
		int result = 0;
		int val2 = 8;
		int val1 = 9;
		result = (val1 >= val2) ? val2+val1 : val2-val1;
		System.out.println(result);
	}

}
