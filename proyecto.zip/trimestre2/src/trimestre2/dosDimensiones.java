package trimestre2;

public class dosDimensiones {
	double base;
	double altura;
	
	public void MostrarDimension() {
		System.out.println("La base y altura es: " + base + " y " + altura);
	}

}
